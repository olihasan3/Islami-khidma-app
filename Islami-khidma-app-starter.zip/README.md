# Islami Khidmah App

Starter structure for Customer, Driver, Shop, Admin, Ride and Payment modules.

## Modules
- Customer
- Driver
- Shop
- Admin
- Rickshaw/Auto Ride
- Payment

This is a front-end starter. Real login, database, GPS, SMS and payment gateway should be connected through a secure backend/API.
